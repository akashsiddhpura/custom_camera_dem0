package com.example.custom_camera

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
